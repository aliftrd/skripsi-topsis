<?php

namespace App\Enums;

enum RatingValueEnum: int
{
    case VERY_HIGHT = 5;
    case HIGHT = 4;
    case MEDIUM = 3;
    case LOW = 2;
    case VERY_LOW = 1;

    public function getLabel(): string
    {
        return match ($this) {
            self::VERY_HIGHT => __('rating-value.very_hight'),
            self::HIGHT => __('rating-value.hight'),
            self::MEDIUM => __('rating-value.medium'),
            self::LOW => __('rating-value.low'),
            self::VERY_LOW => __('rating-value.very_low'),
        };
    }
}
