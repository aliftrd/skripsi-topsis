<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Baris Bahasa Paginasi
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh perpustakaan paginator untuk membuat
    | tautan paginasi sederhana. Anda bebas mengubahnya sesuai keinginan Anda
    | untuk menyesuaikan tampilan agar lebih cocok dengan aplikasi Anda.
    |
    */

    'previous' => '&laquo; Sebelumnya',
    'next' => 'Berikutnya &raquo;',

];
