<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Baris Bahasa Otentikasi
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan selama otentikasi untuk berbagai
    | pesan yang perlu kami tampilkan kepada pengguna. Anda bebas memodifikasi
    | baris bahasa ini sesuai dengan kebutuhan aplikasi Anda.
    |
    */

    'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
    'password' => 'Kata sandi yang diberikan salah.',
    'throttle' => 'Terlalu banyak upaya masuk. Silakan coba lagi dalam :seconds detik.',

    'title' => 'Sistem Pendukung Keputusan Penerimaan Bantuan PKH',
    'signin' => 'Masuk',

    'field.email' => 'Email',
    'field.password' => 'Password',
];
